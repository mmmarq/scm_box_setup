<?php
    $ip = $_SERVER['SERVER_ADDR'];
?>
<!DOCTYPE html>
<html>
<link rel="icon" type="image/png" href="images/tool_box_ico.png">
<title>Rpi SCM in a Box - Main Page</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<body>

<!-- Header -->
<header class="w3-container w3-theme w3-padding" id="myHeader">
  <div class="w3-center">
  <h4>Welcome to</h4>
  <h1 class="w3-xxxlarge w3-animate-bottom">Raspberry Pi Software Configuration Management in a Box</h1>
    <div class="w3-padding-32">
      <img src="images/tool_box.png" class="w3-round w3-grayscale-min" style="width:10%" alt="Tool Box">
    </div>
    <h4>See below the tools you have available to start the job:</h4>
  </div>
</header>

<div class="w3-container">
<hr>
  <div class="w3-card-4">
    <header class="w3-container w3-gray w3-center">
      <h1>First Steps</h1>
    </header>
    <div class="w3-container">
      <ul class="w3-ul">
        <li>Run the commands below to loggin into your Raspberry pi and run setup script:</li>
        <li style="font-family: monospace"># ssh -l pi <?php echo $ip;?></li>
        <li>Password: raspberry</li>
        <li style="font-family: monospace"># cd scm_box_setup</li>
        <li style="font-family: monospace"># git pull</li>
        <li style="font-family: monospace"># sudo ./scm_tool_config.py</li>
        <li>Follow the script instructions to finish setup. After that, Raspberry will reboot!</li>
      </ul>
    </div>
  </div>
</div>

<div class="w3-container">
<hr>
</div>

<div class="w3-row-padding w3-margin-top">

<div class="w3-card-4">
  <header class="w3-container w3-khaki w3-center">
    <img src="images/git-logo.png" class="w3-round w3-grayscale-min" style="width:10%" alt="Git">
  </header>
  <div class="w3-container">
    <ul class="w3-ul">
      <li>Git is a free and open source distributed version control system </li>
      <li>Just open a shell as our pre-defined accounts and start to try git commands</li>
      <li>From your computer run:</li>
      <li><font style="font-family: monospace"># ssh -l dev1 <?php echo $ip;?></font> (password: developer1)</li>
      <li><font style="font-family: monospace"># ssh -l dev2 <?php echo $ip;?></font> (password: developer2)</li>
      <li>To learn more about git, visit <a href="https://git-scm.com/" target="_blank">Git official web site</a></li>
      <li>In case you are trying to access your server from a computer running Windows, you need to install an ssh client</li>
    </ul>
  </div>
</div>

<div class="w3-container">
  &nbsp;
</div>

<div class="w3-card-4">
  <header class="w3-container w3-light-green w3-center">
    <a href="http://<?php echo $ip;?>/mantisbt/" target="_blank"><img src="images/mantis-logo.png" class="w3-round w3-grayscale-min" style="width:15%" alt="MantisBT"></a>
  </header>
  <div class="w3-container">
    <ul class="w3-ul">
      <li>MantisBT is an open source issue tracker that provides a delicate balance between simplicity and power</li>
      <li>Click <a href="http://<?php echo $ip;?>/mantisbt/" target="_blank"><b>here</b></a> to access MantisBT in your local server</li>
      <li>You can login as one of our pre-defined accounts (username: dev1 - password: developer1 or username: dev2 - password: developer2)</li>
      <li>There is also a demo project called "<b>Hello World</b>" to you create your first bug reports</li>
    </ul>
  </div>
</div>

<div class="w3-container">
  &nbsp;
</div>

<div class="w3-card-4">
  <header class="w3-container w3-sand w3-center">
    <a href="http://<?php echo $ip;?>/gerrit/" target="_blank"><img src="images/gerrit-logo.png" class="w3-round w3-grayscale-min" style="width:30%" alt="Gerrit"></a>
  </header>
  <div class="w3-container">
    <ul class="w3-ul">
      <li>Gerrit provides web based code review and repository management for the Git version control system</li>
      <li>Click <a href="http://<?php echo $ip;?>/gerrit/" target="_blank"><b>here</b></a> to access Gerrit in your local server</li>
      <li>To learn more about Gerrit, visit <a href="https://gerrit-documentation.storage.googleapis.com/Documentation/2.13.3/intro-quick.html" target="_blank">Gerrit Quick Introdution</a></li>
      <li>To get our demo "<b>Hello World</b>" source code, run following command when logged in on our server as "dev1" or "dev2" via ssh:</li>
      <li>git clone ssh://<?php echo $ip;?>:29418/HelloWorld</li>
    </ul>
  </div>
</div>

<div class="w3-container">
  &nbsp;
</div>

<div class="w3-card-4">
  <header class="w3-container w3-indigo w3-center">
    <a href="http://<?php echo $ip;?>/jenkins/" target="_blank"><img src="images/jenkins-logo.png" class="w3-round w3-grayscale-min" style="width:15%" alt="Jenkins"></a>
  </header>
  <div class="w3-container">
    <ul class="w3-ul">
      <li>Jenkins is an open source automation server which enables developers to reliably build, test, and deploy their software</li>
      <li>Click <a href="http://<?php echo $ip;?>/jenkins/" target="_blank"><b>here</b></a> to access Jenkins in your local server</li>
      <li>You can login as one of our pre-defined accounts (username: dev1 - password: developer1 or username: dev2 - password: developer2)</li>
      <li>You will see your "<b>Hello World</b>" project been built automatically when someone "Submitt" a code change</li>
      <li>To learn more about Jenkins, visit <a href="https://jenkins.io/doc/book/" target="_blank">Jenkins Handbook</a></li>
    </ul>
  </div>
</div>

<div class="w3-container">
  &nbsp;
</div>

<div class="w3-card-4">
  <header class="w3-container w3-pale-yellow w3-center">
    <a href="http://<?php echo $ip;?>/phpldapadmin/" target="_blank"><img src="images/openldap-logo.png" class="w3-round w3-grayscale-min" style="width:15%" alt="OpenLDAP"></a>
  </header>
  <div class="w3-container">
    <ul class="w3-ul">
      <li>OpenLDAP Software is an open source implementation of the Lightweight Directory Access Protocol</li>
      <li>Click <a href="http://<?php echo $ip;?>/phpldapadmin/" target="_blank"><b>here</b></a> to access OpenLDAP admin page in your local server</li>
      <li>You can login as our pre-defined admin accounts (login DN: cn=admin,dc=ldap,dc=raspberry,dc=pi - password: raspberry)</li>
      <li>There you will be able to add new users. Our default users are "admin", "dev1" and "dev2"</li>
      <li>To learn more about OpenLDAP, visit <a href="http://www.openldap.org/doc/admin24/" target="_blank">OpenLDAP Admin Guide</a></li>
    </ul>
  </div>
</div>

</div>

<div class="w3-container">
  <hr>
</div>

<footer class="w3-container w3-theme-dark w3-padding-16 w3-center">
  <h6>Raspberry Pi SCM in a Box - © 2016 Marcelo Martim Marques</h6>
  <div style="position:relative;bottom:55px;" class="w3-tooltip w3-right">
    <span class="w3-text w3-theme-light w3-padding">Go To Top</span>
    <a class="w3-text-white" href="#myHeader"><span class="w3-xlarge">
    <i class="fa fa-chevron-circle-up"></i></span></a>
  </div>
</footer>

</body>
</html>
